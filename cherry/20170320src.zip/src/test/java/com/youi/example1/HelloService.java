package com.youi.example1;

import org.springframework.stereotype.Service;

/**
 * Created by jinliang on 2016/7/13.
 */
@Service
public class HelloService {

    public void sayHello(){
        System.out.println("hello china!");
        System.out.println("hello china!");
    }
}
