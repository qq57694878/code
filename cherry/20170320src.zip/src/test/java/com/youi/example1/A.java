package com.youi.example1;

import com.youi.business.common.util.MD5Encoder;

/**
 * Created by jinliang on 2016/11/19.
 */
public class A {
    public static void main(String[]args){
        System.out.println(MD5Encoder.encode("1","wdsh"));
    }
}
