package com.youi.business.common.dao;


	/**
	 *虚拟机
	 */

import com.youi.business.common.entity.HW_VIRTUAL_MACHINE;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class HwVirtualMachineDao extends HibernateEntityDao<HW_VIRTUAL_MACHINE>
{
}
