package com.youi.business.common.dao;


	/**
	 *X86服务器
	 */

import com.youi.business.common.entity.HW_X86;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;
@Repository
public class HwX86Dao extends HibernateEntityDao<HW_X86>
{
}
