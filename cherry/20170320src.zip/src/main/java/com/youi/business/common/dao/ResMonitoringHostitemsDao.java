package com.youi.business.common.dao;


	/**
	 *监控主机item值
	 */

import com.youi.business.common.entity.RES_MONITORING_HOSTITEMS;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class ResMonitoringHostitemsDao extends HibernateEntityDao<RES_MONITORING_HOSTITEMS>
{
}
