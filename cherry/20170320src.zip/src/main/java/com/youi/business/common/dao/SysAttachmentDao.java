package com.youi.business.common.dao;


	/**
	 *
	 */

import com.youi.business.common.entity.SYS_ATTACHMENT;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class SysAttachmentDao extends HibernateEntityDao<SYS_ATTACHMENT>
{
}
