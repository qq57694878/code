package com.youi.business.common.dao;


	/**
	 *
	 */

import com.youi.business.common.entity.SW_REQUIREMENT_CHANGE;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class SwRequirementChangeDao extends HibernateEntityDao<SW_REQUIREMENT_CHANGE>
{
}
