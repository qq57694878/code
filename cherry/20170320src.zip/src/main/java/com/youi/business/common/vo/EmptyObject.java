package com.youi.business.common.vo;

import java.io.Serializable;

/**
 * Created by jinliang on 2016/8/8.
 */
public class EmptyObject implements Serializable{
}
