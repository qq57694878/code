package com.youi.business.common.dao;


	/**
	 *
	 */

import com.youi.business.common.entity.PM_BIZ_ATTACHMENT;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class PmBizAttachmentDao extends HibernateEntityDao<PM_BIZ_ATTACHMENT>
{
}
