package com.youi.business.common.dao;


	/**
	 *
	 */

import com.youi.business.common.entity.SYS_ORG_INFO;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class SysOrgInfoDao extends HibernateEntityDao<SYS_ORG_INFO>
{
}
