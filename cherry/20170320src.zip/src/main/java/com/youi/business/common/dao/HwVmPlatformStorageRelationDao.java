package com.youi.business.common.dao;


	/**
	 *虚拟化平台和存储关系表
	 */

import com.youi.business.common.entity.HW_VM_PLATFORM_STORAGE_RELATION;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class HwVmPlatformStorageRelationDao extends HibernateEntityDao<HW_VM_PLATFORM_STORAGE_RELATION>
{
}
