package com.youi.business.common.util;

import java.net.InetAddress;

public class IPv4UtilLong {
  
    private final static int INADDRSZ = 4;  
  
    /** 
     * 把IP地址转化为字节数组 
     * @param ipAddr 
     * @return byte[] 
     */  
    public static byte[] ipToBytesByInet(String ipAddr) {  
        try {  
            return InetAddress.getByName(ipAddr).getAddress();  
        } catch (Exception e) {  
            throw new IllegalArgumentException(ipAddr + " is invalid IP");  
        }  
    }  
  
    /** 
     * 把IP地址转化为long
     * @param ipAddr 
     * @return byte[] 
     */  
    public static byte[] ipToBytesByReg(String ipAddr) {  
        byte[] ret = new byte[4];  
        try {  
            String[] ipArr = ipAddr.split("\\.");  
            ret[0] = (byte) (Integer.parseInt(ipArr[0]) & 0xFF);  
            ret[1] = (byte) (Integer.parseInt(ipArr[1]) & 0xFF);  
            ret[2] = (byte) (Integer.parseInt(ipArr[2]) & 0xFF);  
            ret[3] = (byte) (Integer.parseInt(ipArr[3]) & 0xFF);
            return ret;  
        } catch (Exception e) {  
            throw new IllegalArgumentException(ipAddr + " is invalid IP");  
        }  
  
    }  
  
    /** 
     * 字节数组转化为IP 
     * @param bytes 
     * @return String
     */  
    public static String bytesToIp(byte[] bytes) {  
        return new StringBuffer().append(bytes[0] & 0xFF).append('.').append(  
                bytes[1] & 0xFF).append('.').append(bytes[2] & 0xFF)  
                .append('.').append(bytes[3] & 0xFF).toString();  
    }  
  
    /** 
     * 根据位运算把 byte[] -> long 
     * @param bytes 
     * @return long 
     */  
    public static long bytesToLong(byte[] bytes) {
        long addr = bytes[3] & 0xFF;  
        addr |= ((bytes[2] << 8) & 0xFF00);  
        addr |= ((bytes[1] << 16) & 0xFF0000);  
        addr |= ((bytes[0] << 24) & 0xFF000000);  
        return addr;  
    }  
  
    /** 
     * 把IP地址转化为long
     * @param ipAddr 
     * @return long 
     */  
    public static long ipToLong(String ipAddr) {  
        try {  
            return bytesToLong(ipToBytesByInet(ipAddr));  
        } catch (Exception e) {  
            throw new IllegalArgumentException(ipAddr + " is invalid IP");  
        }  
    }  
  
    /** 
     * ipInt -> byte[] 
     * @param ipInt 
     * @return byte[] 
     */  
    public static byte[] longToBytes(long ipInt) {  
        byte[] ipAddr = new byte[INADDRSZ];  
        ipAddr[0] = (byte) ((ipInt >>> 24) & 0xFF);  
        ipAddr[1] = (byte) ((ipInt >>> 16) & 0xFF);  
        ipAddr[2] = (byte) ((ipInt >>> 8) & 0xFF);  
        ipAddr[3] = (byte) (ipInt & 0xFF);  
        return ipAddr;  
    }  
  
    /** 
     * 把long>ip地址 
     * @param ipInt 
     * @return String 
     */  
    public static String longToIp(long ipInt) {  
        return new StringBuilder().append(((ipInt >> 24) & 0xff)).append('.')  
                .append((ipInt >> 16) & 0xff).append('.').append(  
                        (ipInt >> 8) & 0xff).append('.').append((ipInt & 0xff))  
                .toString();  
    }  
  
    /** 
     * 把192.168.1.1/24 转化为long数组范围 
     * @param ipAndMask 
     * @return long[] 
     */  
    public static long[] getIPLongScope(String ipAndMask) {  
  
        String[] ipArr = ipAndMask.split("/");  
        if (ipArr.length != 2) {  
            throw new IllegalArgumentException("invalid ipAndMask with: "  
                    + ipAndMask);  
        }  
        int netMask = Integer.valueOf(ipArr[1].trim());  
        if (netMask < 0 || netMask > 31) {  
            throw new IllegalArgumentException("invalid ipAndMask with: "  
                    + ipAndMask);  
        }  
        long ipInt = IPv4UtilLong.ipToLong(ipArr[0]);
        long netIP = ipInt & (0xFFFFFFFF << (32 - netMask));  
        long hostScope = (0xFFFFFFFF >>> netMask);  
        return new long[] { netIP, netIP + hostScope };  
  
    }  
  
    /** 
     * 把192.168.1.1/24 转化为IP数组范围 
     * @param ipAndMask 
     * @return String[] 
     */  
    public static String[] getIPAddrScope(String ipAndMask) {  
        long[] ipIntArr = IPv4UtilLong.getIPLongScope(ipAndMask);
        return new String[] { IPv4UtilLong.longToIp(ipIntArr[0]),
                IPv4UtilLong.longToIp(ipIntArr[0]) };
    }  
  
    /** 
     * 根据IP 子网掩码（192.168.1.1 255.255.255.0）转化为IP段 
     * @param ipAddr ipAddr 
     * @param mask mask 
     * @return long[] 
     */  
    public static long[] getIPLongScope(String ipAddr, String mask) {  
  
        long ipInt;
        long netMaskInt = 0, ipcount = 0;  
        try {  
            ipInt = IPv4UtilLong.ipToLong(ipAddr);
            if (null == mask || "".equals(mask)) {  
                return new long[] { ipInt, ipInt };  
            }  
            netMaskInt = IPv4UtilLong.ipToLong(mask);
            ipcount = IPv4UtilLong.ipToLong("255.255.255.255") - netMaskInt;
            long netIP = ipInt & netMaskInt;
            long hostScope = netIP + ipcount;  
            return new long[] { netIP, hostScope };  
        } catch (Exception e) {  
            throw new IllegalArgumentException("invalid ip scope express  ip:"  
                    + ipAddr + "  mask:" + mask);  
        }  
  
    }  
  
    /** 
     * 根据IP 子网掩码（192.168.1.1 255.255.255.0）转化为IP段 
     * @param ipAddr ipAddr 
     * @param mask mask 
     * @return String[] 
     */  
    public static String[] getIPStrScope(String ipAddr, String mask) {  
        long[] ipIntArr = IPv4UtilLong.getIPLongScope(ipAddr, mask);
        return new String[] { IPv4UtilLong.longToIp(ipIntArr[0]),
                IPv4UtilLong.longToIp(ipIntArr[0]) };
    }
    /**
     * 根据字符串子网掩码获得数字型子网掩码（255.255.255.0）转化为IP段
     * @param mask mask
     * @return String[]
     */
    public static long getMaskInt( String mask) {
        long i = IPv4UtilLong.ipToLong("255.255.255.255") - IPv4UtilLong.ipToLong(mask);
        Double d = 32-Math.log1p(i)/Math.log(2);
        return d.intValue();
    }

    /** 
     * @param args 
     * @throws Exception 
     */  
    public static void main(String[] args) throws Exception {
        String ipAddr = "192.168.1.1";

        byte[] bytearr = IPv4UtilLong.ipToBytesByReg(ipAddr);
        long a = IPv4UtilLong.bytesToLong(bytearr);
        long c= (long)(a+Math.pow(2,32));
     System.out.println( c);

            // test1();
        }
public static void test(){
    String ipAddr = "192.168.8.1";

    byte[] bytearr = IPv4UtilLong.ipToBytesByInet(ipAddr);


    StringBuffer byteStr = new StringBuffer();

    for (byte b : bytearr) {
        if (byteStr.length() == 0) {
            byteStr.append(b);
        } else {
            byteStr.append("," + b);
        }
    }
    System.out.println("IP: " + ipAddr + " ByInet --> byte[]: [ " + byteStr
            + " ]");

    bytearr = IPv4UtilLong.ipToBytesByReg(ipAddr);
    byteStr = new StringBuffer();

    for (byte b : bytearr) {
        if (byteStr.length() == 0) {
            byteStr.append(b);
        } else {
            byteStr.append("," + b);
        }
    }
    System.out.println("IP: " + ipAddr + " ByReg  --> byte[]: [ " + byteStr
            + " ]");

    System.out.println("byte[]: " + byteStr + " --> IP: "
            + IPv4UtilLong.bytesToIp(bytearr));

    long ipInt = IPv4UtilLong.ipToLong(ipAddr);

    System.out.println("IP: " + ipAddr + "  --> long: " + ipInt);

    System.out.println("long: " + ipInt + " --> IP: "
            + IPv4UtilLong.longToIp(ipInt));

    String ipAndMask = "192.168.1.1/24";

    long[] ipscope = IPv4UtilLong.getIPLongScope(ipAndMask);
    System.out.println(ipAndMask + " --> long地址段：[ " + ipscope[0] + ","
            + ipscope[1] + " ]");
    System.out.println("IP 地址段内host数"+(ipscope[1]-ipscope[0]));

    System.out.println(ipAndMask + " --> IP 地址段：[ "
            + IPv4UtilLong.longToIp(ipscope[0]) + ","
            + IPv4UtilLong.longToIp(ipscope[1]) + " ]");

    String ipAddr1 = "192.168.1.1", ipMask1 = "255.255.255.0";

    long[] ipscope1 = IPv4UtilLong.getIPLongScope(ipAddr1, ipMask1);
    System.out.println(ipAddr1 + " , " + ipMask1 + "  --> long地址段 ：[ "
            + ipscope1[0] + "," + ipscope1[1] + " ]");

    System.out.println(ipAddr1 + " , " + ipMask1 + "  --> IP地址段 ：[ "
            + IPv4UtilLong.longToIp(ipscope1[0]) + ","
            + IPv4UtilLong.longToIp(ipscope1[1]) + " ]");
    System.out.println(IPv4UtilLong.getMaskInt("255.255.255.0"));
}
    public static void test1(){
        String ipAndMask = "192.168.1.1/24";
        long[] ipscope = IPv4UtilLong.getIPLongScope(ipAndMask);
        for( long i=ipscope[0];i<=ipscope[1];i++){
            System.out.println(IPv4UtilLong.longToIp(i));
        }
    }
}