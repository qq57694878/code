package com.youi.business.common.dao;


	/**
	 *snmp请求结果表
	 */

import com.youi.business.common.entity.RES_SNMP_REQ_RESULT;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class ResSnmpReqResultDao extends HibernateEntityDao<RES_SNMP_REQ_RESULT>
{
}
