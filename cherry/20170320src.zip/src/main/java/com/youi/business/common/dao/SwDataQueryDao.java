package com.youi.business.common.dao;


	/**
	 *数据查询
	 */

import com.youi.business.common.entity.SW_DATA_QUERY;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class SwDataQueryDao extends HibernateEntityDao<SW_DATA_QUERY>
{
}
