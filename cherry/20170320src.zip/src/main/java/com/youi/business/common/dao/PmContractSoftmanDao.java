package com.youi.business.common.dao;


	/**
	 *
	 */

import com.youi.business.common.entity.PM_CONTRACT_SOFTMAN;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class PmContractSoftmanDao extends HibernateEntityDao<PM_CONTRACT_SOFTMAN>
{
}
