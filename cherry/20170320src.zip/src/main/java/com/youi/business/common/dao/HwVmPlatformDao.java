package com.youi.business.common.dao;


	/**
	 *虚拟化平台
	 */

import com.youi.business.common.entity.HW_VM_PLATFORM;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class HwVmPlatformDao extends HibernateEntityDao<HW_VM_PLATFORM>
{
}
