package com.youi.business.common.dao;


	/**
	 *中间件
	 */

import com.youi.business.common.entity.HW_MIDDLEWARE;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class HwMiddlewareDao extends HibernateEntityDao<HW_MIDDLEWARE>
{
}
