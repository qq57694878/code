package com.youi.business.common.dao;


	/**
	 *程序设置参数表
	 */

import com.youi.business.common.entity.RES_SETTINGS;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class ResSettingsDao extends HibernateEntityDao<RES_SETTINGS>
{
}
