package com.youi.business.common.dao;


	/**
	 *虚拟化平台和x86服务器关系表
	 */

import com.youi.business.common.entity.HW_VM_PLATFORM_X86_RELATION;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class HwVmPlatformX86RelationDao extends HibernateEntityDao<HW_VM_PLATFORM_X86_RELATION>
{
}
