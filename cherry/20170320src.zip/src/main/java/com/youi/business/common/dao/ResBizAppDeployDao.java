package com.youi.business.common.dao;


	/**
	 *
	 */

import com.youi.business.common.entity.RES_BIZ_APP_DEPLOY;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class ResBizAppDeployDao extends HibernateEntityDao<RES_BIZ_APP_DEPLOY>
{
}
