package com.youi.business.common.dao;


	/**
	 *
	 */

import com.youi.business.common.entity.IP_ADDRESS;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class IpAddressDao extends HibernateEntityDao<IP_ADDRESS>
{
}
