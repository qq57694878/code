package com.youi.business.common.dao;


	/**
	 *数据修改
	 */

import com.youi.business.common.entity.SW_DATA_CHANGE;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class SwDataChangeDao extends HibernateEntityDao<SW_DATA_CHANGE>
{
}
