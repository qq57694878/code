package com.youi.business.common.dao;


	/**
	 *
	 */

import com.youi.business.common.entity.RES_MONITORING_EVENTS;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class ResMonitoringEventsDao extends HibernateEntityDao<RES_MONITORING_EVENTS>
{
}
