package com.youi.business.common.dao;


	/**
	 *监控主机状态
	 */

import com.youi.business.common.entity.RES_MONITORING_HOSTTRIGGER;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class ResMonitoringHostTriggerDao extends HibernateEntityDao<RES_MONITORING_HOSTTRIGGER>
{
}
