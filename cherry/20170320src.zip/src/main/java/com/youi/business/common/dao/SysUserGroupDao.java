package com.youi.business.common.dao;


	/**
	 *
	 */

import com.youi.business.common.entity.SYS_USER_GROUP;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class SysUserGroupDao extends HibernateEntityDao<SYS_USER_GROUP>
{
}
