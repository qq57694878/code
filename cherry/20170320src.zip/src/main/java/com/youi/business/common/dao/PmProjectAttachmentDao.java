package com.youi.business.common.dao;


	/**
	 *
	 */

import com.youi.business.common.entity.PM_PROJECT_ATTACHMENT;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class PmProjectAttachmentDao extends HibernateEntityDao<PM_PROJECT_ATTACHMENT>
{
}
