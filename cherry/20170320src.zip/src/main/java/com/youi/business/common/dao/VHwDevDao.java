package com.youi.business.common.dao;


	/**
	 *VIEW
	 */

import com.youi.business.common.entity.V_HW_DEV;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class VHwDevDao extends HibernateEntityDao<V_HW_DEV>
{
}
