package com.youi.business.common.dao;


	/**
	 *
	 */

import com.youi.business.common.entity.PM_PROCUREMENT;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class PmProcurementDao extends HibernateEntityDao<PM_PROCUREMENT>
{
}
