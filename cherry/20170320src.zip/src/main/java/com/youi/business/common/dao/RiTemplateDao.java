package com.youi.business.common.dao;


	/**
	 *
	 */

import com.youi.business.common.entity.RI_TEMPLATE;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class RiTemplateDao extends HibernateEntityDao<RI_TEMPLATE>
{
}
