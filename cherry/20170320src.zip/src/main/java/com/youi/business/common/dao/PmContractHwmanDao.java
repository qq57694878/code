package com.youi.business.common.dao;


	/**
	 *
	 */

import com.youi.business.common.entity.PM_CONTRACT_HWMAN;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class PmContractHwmanDao extends HibernateEntityDao<PM_CONTRACT_HWMAN>
{
}
