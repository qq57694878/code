package com.youi.business.common.dao;


	/**
	 *IP地址组
	 */

import com.youi.business.common.entity.IP_ADD_GROUP;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class IpAddGroupDao extends HibernateEntityDao<IP_ADD_GROUP>
{
}
