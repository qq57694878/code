package com.youi.business.common.dao;


	/**
	 *数据库
	 */

import com.youi.business.common.entity.HW_DATABASE;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class HwDatabaseDao extends HibernateEntityDao<HW_DATABASE>
{
}
