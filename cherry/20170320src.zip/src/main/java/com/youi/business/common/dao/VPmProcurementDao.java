package com.youi.business.common.dao;


	/**
	 *VIEW
	 */

import com.youi.business.common.entity.V_PM_PROCUREMENT;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class VPmProcurementDao extends HibernateEntityDao<V_PM_PROCUREMENT>
{
}
