package com.youi.business.common.dao;


	/**
	 *
	 */

import com.youi.business.common.entity.HW_COMPUTER_ROOM;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class HwComputerRoomDao extends HibernateEntityDao<HW_COMPUTER_ROOM>
{
}
