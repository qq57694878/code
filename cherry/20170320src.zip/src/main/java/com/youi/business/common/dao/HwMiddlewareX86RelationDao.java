package com.youi.business.common.dao;


	/**
	 *中间件和x86服务器关系表
	 */

import com.youi.business.common.entity.HW_MIDDLEWARE_X86_RELATION;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class HwMiddlewareX86RelationDao extends HibernateEntityDao<HW_MIDDLEWARE_X86_RELATION>
{
}
