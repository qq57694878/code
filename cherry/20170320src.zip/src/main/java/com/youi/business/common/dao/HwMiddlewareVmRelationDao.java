package com.youi.business.common.dao;


	/**
	 *中间件和虚拟机关系表
	 */

import com.youi.business.common.entity.HW_MIDDLEWARE_VM_RELATION;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class HwMiddlewareVmRelationDao extends HibernateEntityDao<HW_MIDDLEWARE_VM_RELATION>
{
}
