package com.youi.business.common.dao;


	/**
	 *业务系统
	 */

import com.youi.business.common.entity.RES_BUSSINESS_APP;
import com.youi.core.hibernate.HibernateEntityDao;

import org.springframework.stereotype.Repository;

@Repository
public class ResBussinessAppDao extends HibernateEntityDao<RES_BUSSINESS_APP>
{
}
