package com.youi.business.common.dao;


	/**
	 *
	 */

import com.youi.business.common.entity.SYS_ACT_LOG;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class SysActLogDao extends HibernateEntityDao<SYS_ACT_LOG>
{
}
