package com.youi.business.common.dao;


	/**
	 *
	 */

import com.youi.business.common.entity.SYS_USER_ORG;
import com.youi.core.hibernate.HibernateEntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class SysUserOrgDao extends HibernateEntityDao<SYS_USER_ORG>
{
}
